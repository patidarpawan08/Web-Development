# FoodOrdering
Food ordering application for CS5200

Jersey module - For providing REST service from server

